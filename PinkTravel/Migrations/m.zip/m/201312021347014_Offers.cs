namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Offers : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Offers",
                c => new
                    {
                        OfferId = c.Int(nullable: false, identity: true),
                        HotelName = c.String(nullable: false),
                        LocationName = c.String(nullable: false),
                        HotelImage = c.Binary(),
                        LocationImage = c.Binary(),
                        AddedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.OfferId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Offers");
        }
    }
}
