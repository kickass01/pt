namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ImageNames : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Offers", "HotelImageFileName", c => c.String());
            AddColumn("dbo.Offers", "LocationImageFileName", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Offers", "LocationImageFileName");
            DropColumn("dbo.Offers", "HotelImageFileName");
        }
    }
}
