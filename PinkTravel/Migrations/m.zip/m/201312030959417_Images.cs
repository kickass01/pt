namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Images : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ImageModels",
                c => new
                    {
                        FileName = c.String(nullable: false, maxLength: 128),
                        ContentType = c.String(),
                        ContentLength = c.Int(nullable: false),
                        Content = c.Binary(),
                    })
                .PrimaryKey(t => t.FileName);
            
            AddColumn("dbo.Offers", "HotelImageName", c => c.String());
            AddColumn("dbo.Offers", "LocationImageName", c => c.String());
            DropColumn("dbo.Offers", "HotelImage");
            DropColumn("dbo.Offers", "LocationImage");
            DropColumn("dbo.Offers", "HotelImageFileName");
            DropColumn("dbo.Offers", "LocationImageFileName");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Offers", "LocationImageFileName", c => c.String());
            AddColumn("dbo.Offers", "HotelImageFileName", c => c.String());
            AddColumn("dbo.Offers", "LocationImage", c => c.Binary());
            AddColumn("dbo.Offers", "HotelImage", c => c.Binary());
            DropColumn("dbo.Offers", "LocationImageName");
            DropColumn("dbo.Offers", "HotelImageName");
            DropTable("dbo.ImageModels");
        }
    }
}
