namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class HashImages : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ImageModels", "Hash", c => c.Binary());
        }
        
        public override void Down()
        {
            DropColumn("dbo.ImageModels", "Hash");
        }
    }
}
