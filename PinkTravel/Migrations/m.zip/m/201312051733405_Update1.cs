namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Update1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Offers", "HotelImage_FileName", c => c.String(maxLength: 128));
            AlterColumn("dbo.Offers", "LocationImage_FileName", c => c.String(maxLength: 128));
            AddForeignKey("dbo.Offers", "HotelImage_FileName", "dbo.ImageModels", "FileName");
            AddForeignKey("dbo.Offers", "LocationImage_FileName", "dbo.ImageModels", "FileName");
            CreateIndex("dbo.Offers", "HotelImage_FileName");
            CreateIndex("dbo.Offers", "LocationImage_FileName");
            DropColumn("dbo.Offers", "HotelImageName");
            DropColumn("dbo.Offers", "LocationImageName");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Offers", "LocationImageName", c => c.String());
            AddColumn("dbo.Offers", "HotelImageName", c => c.String());
            DropIndex("dbo.Offers", new[] { "LocationImage_FileName" });
            DropIndex("dbo.Offers", new[] { "HotelImage_FileName" });
            DropForeignKey("dbo.Offers", "LocationImage_FileName", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "HotelImage_FileName", "dbo.ImageModels");
            DropColumn("dbo.Offers", "LocationImage_FileName");
            DropColumn("dbo.Offers", "HotelImage_FileName");
        }
    }
}
