namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemovedImageModel : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Offers", "HotelImage_FileName", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "LocationImage_FileName", "dbo.ImageModels");
            DropIndex("dbo.Offers", new[] { "HotelImage_FileName" });
            DropIndex("dbo.Offers", new[] { "LocationImage_FileName" });
            AddColumn("dbo.Offers", "HotelImage", c => c.String());
            AddColumn("dbo.Offers", "LocationImage", c => c.String());
            DropColumn("dbo.Offers", "HotelImage_FileName");
            DropColumn("dbo.Offers", "LocationImage_FileName");
            DropTable("dbo.ImageModels");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.ImageModels",
                c => new
                    {
                        FileName = c.String(nullable: false, maxLength: 128),
                        ContentType = c.String(),
                        ContentLength = c.Int(nullable: false),
                        Content = c.Binary(),
                        Hash = c.Binary(),
                    })
                .PrimaryKey(t => t.FileName);
            
            AddColumn("dbo.Offers", "LocationImage_FileName", c => c.String(maxLength: 128));
            AddColumn("dbo.Offers", "HotelImage_FileName", c => c.String(maxLength: 128));
            DropColumn("dbo.Offers", "LocationImage");
            DropColumn("dbo.Offers", "HotelImage");
            CreateIndex("dbo.Offers", "LocationImage_FileName");
            CreateIndex("dbo.Offers", "HotelImage_FileName");
            AddForeignKey("dbo.Offers", "LocationImage_FileName", "dbo.ImageModels", "FileName");
            AddForeignKey("dbo.Offers", "HotelImage_FileName", "dbo.ImageModels", "FileName");
        }
    }
}
