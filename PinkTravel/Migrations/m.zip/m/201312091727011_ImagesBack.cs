namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ImagesBack : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ImageModels",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        FileName = c.String(),
                        FileUrl = c.String(),
                        ContentType = c.String(),
                        ContentLength = c.Int(nullable: false),
                        CropX1 = c.Int(nullable: false),
                        CropX2 = c.Int(nullable: false),
                        CropY1 = c.Int(nullable: false),
                        CropY2 = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Offers", "HotelImage_Id", c => c.Int());
            AddColumn("dbo.Offers", "LocationImage_Id", c => c.Int());
            AddForeignKey("dbo.Offers", "HotelImage_Id", "dbo.ImageModels", "Id");
            AddForeignKey("dbo.Offers", "LocationImage_Id", "dbo.ImageModels", "Id");
            CreateIndex("dbo.Offers", "HotelImage_Id");
            CreateIndex("dbo.Offers", "LocationImage_Id");
            DropColumn("dbo.Offers", "HotelImage");
            DropColumn("dbo.Offers", "LocationImage");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Offers", "LocationImage", c => c.String());
            AddColumn("dbo.Offers", "HotelImage", c => c.String());
            DropIndex("dbo.Offers", new[] { "LocationImage_Id" });
            DropIndex("dbo.Offers", new[] { "HotelImage_Id" });
            DropForeignKey("dbo.Offers", "LocationImage_Id", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "HotelImage_Id", "dbo.ImageModels");
            DropColumn("dbo.Offers", "LocationImage_Id");
            DropColumn("dbo.Offers", "HotelImage_Id");
            DropTable("dbo.ImageModels");
        }
    }
}
