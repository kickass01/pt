namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NoScaffoldCropValues : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.ImageModels", "CropX1");
            DropColumn("dbo.ImageModels", "CropX2");
            DropColumn("dbo.ImageModels", "CropY1");
            DropColumn("dbo.ImageModels", "CropY2");
        }
        
        public override void Down()
        {
            AddColumn("dbo.ImageModels", "CropY2", c => c.Int(nullable: false));
            AddColumn("dbo.ImageModels", "CropY1", c => c.Int(nullable: false));
            AddColumn("dbo.ImageModels", "CropX2", c => c.Int(nullable: false));
            AddColumn("dbo.ImageModels", "CropX1", c => c.Int(nullable: false));
        }
    }
}
