namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedImageFK : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Offers", "HotelImage_Id", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "LocationImage_Id", "dbo.ImageModels");
            DropIndex("dbo.Offers", new[] { "HotelImage_Id" });
            DropIndex("dbo.Offers", new[] { "LocationImage_Id" });
            RenameColumn(table: "dbo.Offers", name: "HotelImage_Id", newName: "HotelImageId");
            RenameColumn(table: "dbo.Offers", name: "LocationImage_Id", newName: "LocationImageId");
            AddForeignKey("dbo.Offers", "HotelImageId", "dbo.ImageModels", "Id", cascadeDelete: false);
            AddForeignKey("dbo.Offers", "LocationImageId", "dbo.ImageModels", "Id", cascadeDelete: false);
            CreateIndex("dbo.Offers", "HotelImageId");
            CreateIndex("dbo.Offers", "LocationImageId");
        }
        
        public override void Down()
        {
            DropIndex("dbo.Offers", new[] { "LocationImageId" });
            DropIndex("dbo.Offers", new[] { "HotelImageId" });
            DropForeignKey("dbo.Offers", "LocationImageId", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "HotelImageId", "dbo.ImageModels");
            RenameColumn(table: "dbo.Offers", name: "LocationImageId", newName: "LocationImage_Id");
            RenameColumn(table: "dbo.Offers", name: "HotelImageId", newName: "HotelImage_Id");
            CreateIndex("dbo.Offers", "LocationImage_Id");
            CreateIndex("dbo.Offers", "HotelImage_Id");
            AddForeignKey("dbo.Offers", "LocationImage_Id", "dbo.ImageModels", "Id");
            AddForeignKey("dbo.Offers", "HotelImage_Id", "dbo.ImageModels", "Id");
        }
    }
}
