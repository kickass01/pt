namespace PinkTravel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class S : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Offers", "HotelImage_FileName", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "LocationImage_FileName", "dbo.ImageModels");
            DropIndex("dbo.Offers", new[] { "HotelImage_FileName" });
            DropIndex("dbo.Offers", new[] { "LocationImage_FileName" });
            RenameColumn(table: "dbo.Offers", name: "HotelImage_FileName", newName: "HotelImageId");
            RenameColumn(table: "dbo.Offers", name: "LocationImage_FileName", newName: "LocationImageId");
            AddColumn("dbo.ImageModels", "Id", c => c.Int(nullable: false, identity: true));
            AddColumn("dbo.ImageModels", "FileUrl", c => c.String());
            AlterColumn("dbo.ImageModels", "FileName", c => c.String(nullable: false));
            DropPrimaryKey("dbo.ImageModels", new[] { "FileName" });
            AddPrimaryKey("dbo.ImageModels", "Id");
            AddForeignKey("dbo.Offers", "HotelImageId", "dbo.ImageModels", "Id", cascadeDelete: true);
            AddForeignKey("dbo.Offers", "LocationImageId", "dbo.ImageModels", "Id", cascadeDelete: true);
            CreateIndex("dbo.Offers", "HotelImageId");
            CreateIndex("dbo.Offers", "LocationImageId");
            DropColumn("dbo.ImageModels", "Content");
            DropColumn("dbo.ImageModels", "Hash");
        }
        
        public override void Down()
        {
            AddColumn("dbo.ImageModels", "Hash", c => c.Binary());
            AddColumn("dbo.ImageModels", "Content", c => c.Binary());
            DropIndex("dbo.Offers", new[] { "LocationImageId" });
            DropIndex("dbo.Offers", new[] { "HotelImageId" });
            DropForeignKey("dbo.Offers", "LocationImageId", "dbo.ImageModels");
            DropForeignKey("dbo.Offers", "HotelImageId", "dbo.ImageModels");
            DropPrimaryKey("dbo.ImageModels", new[] { "Id" });
            AlterColumn("dbo.ImageModels", "FileName", c => c.String(nullable: false, maxLength: 128));
            AddPrimaryKey("dbo.ImageModels", "FileName");
            DropColumn("dbo.ImageModels", "FileUrl");
            DropColumn("dbo.ImageModels", "Id");
            RenameColumn(table: "dbo.Offers", name: "LocationImageId", newName: "LocationImage_FileName");
            RenameColumn(table: "dbo.Offers", name: "HotelImageId", newName: "HotelImage_FileName");
            CreateIndex("dbo.Offers", "LocationImage_FileName");
            CreateIndex("dbo.Offers", "HotelImage_FileName");
            AddForeignKey("dbo.Offers", "LocationImage_FileName", "dbo.ImageModels", "FileName");
            AddForeignKey("dbo.Offers", "HotelImage_FileName", "dbo.ImageModels", "FileName");
        }
    }
}
